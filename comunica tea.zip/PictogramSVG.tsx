import React from 'react';
import { AvatarConfig } from '../types';

interface PictogramSVGProps {
  label?: string;
  emoji?: string;
  className?: string;
  category?: string;
  genderTheme?: 'boy' | 'girl' | 'neutral';
  avatarConfig?: AvatarConfig;
}

declare global {
  interface Window {
    __comunicateaActiveTheme__?: 'boy' | 'girl' | 'neutral';
  }
}

export const PictogramSVG: React.FC<PictogramSVGProps> = ({ 
  label = '', 
  emoji = '', 
  className = "w-full h-full",
  category = '',
  genderTheme,
  avatarConfig
}) => {
  const normLabel = label.toLowerCase().trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, ""); // Remove accents

  const normEmoji = emoji.trim();

  // Resolve the active gender theme from prop, global window state, or localStorage
  const activeGenderTheme: 'boy' | 'girl' | 'neutral' = 
    genderTheme || 
    window.__comunicateaActiveTheme__ || 
    (localStorage.getItem('comunicatea_active_theme') as any) || 
    'neutral';

  // Helper patterns for SVG drawing components
  const COLORS = {
    outline: "#111827", // Rich black outline
    skin: avatarConfig?.skinColor || "#ffdfd0", // Cute warm pale skin peach color
    hair: avatarConfig?.hairColor || "#5c3a21", // Medium dark warm brown hair
    pink: "#ec4899", // Vibrant happy pink
    pinkLight: "#fbcfe8", // Light pink for cheeks/accents
    blue: "#3b82f6", // Happy blue
    blueLight: "#93c5fd", // Light soft blue for water
    green: "#10b981", // Emerald green
    yellow: "#eab308", // Yellow toy blocks
    red: "#ef4444", // Danger/Pain red
    white: "#ffffff",
    grey: "#6b7280", // Gray for neutral
    greyLight: "#e5e7eb",
    shirt: avatarConfig?.clothingColor || ""
  };

  // Dynamically map colors based on the selected theme
  const shirtColor = COLORS.shirt || (activeGenderTheme === 'boy' ? COLORS.blue : activeGenderTheme === 'neutral' ? COLORS.grey : COLORS.pink);
  const cheekColor = activeGenderTheme === 'boy' ? COLORS.blueLight : activeGenderTheme === 'neutral' ? COLORS.greyLight : COLORS.pinkLight;
  const accentColor = activeGenderTheme === 'boy' ? COLORS.blue : activeGenderTheme === 'neutral' ? COLORS.grey : COLORS.pink;
  const accentLightColor = activeGenderTheme === 'boy' ? COLORS.blueLight : activeGenderTheme === 'neutral' ? COLORS.greyLight : COLORS.pinkLight;

  // Reusable character elements (face, eyes, ponytail, bow)
  const drawBaseGirl = (options: { 
    eyeType?: 'normal' | 'happy' | 'sad' | 'pain' | 'sleep'; 
    mouthType?: 'smile' | 'neutral' | 'sad' | 'open' | 'pain';
    cheekWidth?: number;
  } = {}) => {
    const { eyeType = 'normal', mouthType = 'smile' } = options;

    return (
      <>
        {/* Ponytail Back (Only for girls) */}
        {activeGenderTheme === 'girl' && (
          <path 
            d="M20,38 C12,38 8,46 10,54 C12,62 20,62 24,56 C28,50 26,40 20,38 Z" 
            fill={COLORS.hair} 
            stroke={COLORS.outline} 
            strokeWidth="3.5" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
          />
        )}
        
        {/* Hair Bow (Only for girls) */}
        {activeGenderTheme === 'girl' && (
          <>
            <path 
              d="M24,36 C22,30 26,26 29,30 C31,33 30,38 29,38 C28,38 25,41 24,36 Z" 
              fill={COLORS.pink} 
              stroke={COLORS.outline} 
              strokeWidth="3" 
              strokeLinejoin="round" 
            />
            <path 
              d="M26,41 C21,43 18,39 21,35 C23,32 27,35 27,37 Q27,39 26,41 Z" 
              fill={COLORS.pink} 
              stroke={COLORS.outline} 
              strokeWidth="3" 
              strokeLinejoin="round" 
            />
            <circle cx="25.5" cy="38" r="3.5" fill={COLORS.pink} stroke={COLORS.outline} strokeWidth="2.5" />
          </>
        )}

        {/* Head Shell */}
        <circle 
          cx="50" 
          cy="48" 
          r="19" 
          fill={COLORS.skin} 
          stroke={COLORS.outline} 
          strokeWidth="3.5" 
        />

        {/* Ears */}
        <circle cx="31" cy="48" r="4" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3" />
        <circle cx="69" cy="48" r="4" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3" />

        {/* Hair Base & Bangs */}
        {activeGenderTheme === 'girl' && (
          <>
            <path 
              d="M31,44 C31,31 69,31 69,44 Q60,34 50,34 Q40,34 31,44 Z" 
              fill={COLORS.hair} 
              stroke={COLORS.outline} 
              strokeWidth="3.5" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
            />
            {/* Hair Bang details */}
            <path 
              d="M31,44 L37,39 L41,43 L49,38 L54,42 L61,38 L69,44" 
              fill="none" 
              stroke={COLORS.outline} 
              strokeWidth="3" 
              strokeLinecap="round" 
            />
          </>
        )}

        {/* Character Hair Rendering based on avatarConfig or default theme */}
        {avatarConfig ? (
          <>
            {/* Hair Base */}
            {avatarConfig.hairStyle === 'bald' ? null : (
              <path 
                d={
                  avatarConfig.hairStyle === 'long' ? "M31,44 C31,24 69,24 69,44 L72,68 L28,68 Z" :
                  avatarConfig.hairStyle === 'bob' ? "M31,44 C31,28 69,28 69,44 L74,58 L26,58 Z" :
                  "M31,44 C31,29 69,29 69,44 Q50,34 31,44 Z"
                }
                fill={COLORS.hair} 
                stroke={COLORS.outline} 
                strokeWidth="3.5" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
              />
            )}
            {/* Hair Details */}
            {avatarConfig.hairStyle === 'spiky' && (
              <path d="M44,24 L46,18 L50,22 Q54,17 58,23" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="3" strokeLinecap="round" />
            )}
            {avatarConfig.hairStyle === 'curly' && (
              <>
                <circle cx="40" cy="30" r="4" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="2" />
                <circle cx="50" cy="28" r="4" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="2" />
                <circle cx="60" cy="30" r="4" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="2" />
              </>
            )}
          </>
        ) : (
          <>
            {activeGenderTheme === 'boy' && (
              <>
                <path d="M31,44 C27,42 27,32 35,27 C38,23 48,22 55,24 C62,26 68,31 69,44 Q60,32 50,32 Q40,32 31,44 Z" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M44,24 L46,18 L50,22 Q54,17 58,23" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
              </>
            )}
            {activeGenderTheme === 'girl' && (
              <>
                <path d="M31,44 C31,31 69,31 69,44 Q60,34 50,34 Q40,34 31,44 Z" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M31,44 L37,39 L41,43 L49,38 L54,42 L61,38 L69,44" fill="none" stroke={COLORS.outline} strokeWidth="3" strokeLinecap="round" />
              </>
            )}
            {activeGenderTheme === 'neutral' && (
              <>
                <path d="M31,44 C31,29 69,29 69,44 Q50,34 31,44 Z" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M31,44 L36,40 M69,44 L64,40" fill="none" stroke={COLORS.outline} strokeWidth="2.5" strokeLinecap="round" />
              </>
            )}
          </>
        )}

        {activeGenderTheme === 'neutral' && (
          <>
            {/* Clean minimal unisex haircut */}
            <path 
              d="M31,44 C31,29 69,29 69,44 Q50,34 31,44 Z" 
              fill={COLORS.hair} 
              stroke={COLORS.outline} 
              strokeWidth="3.5" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
            />
            <path 
              d="M31,44 L36,40 M69,44 L64,40" 
              fill="none" 
              stroke={COLORS.outline} 
              strokeWidth="2.5" 
              strokeLinecap="round" 
            />
          </>
        )}

        {/* Cheeks */}
        <ellipse cx="38" cy="52" rx="3" ry="1.5" fill={cheekColor} />
        <ellipse cx="62" cy="52" rx="3" ry="1.5" fill={cheekColor} />

        {/* Eyes */}
        {eyeType === 'normal' && (
          <>
            <ellipse cx="42" cy="47" rx="2.5" ry="3.5" fill={avatarConfig?.eyeColor || COLORS.outline} />
            <ellipse cx="58" cy="47" rx="2.5" ry="3.5" fill={avatarConfig?.eyeColor || COLORS.outline} />
            <circle cx="41.2" cy="45.5" r="1" fill={COLORS.white} />
            <circle cx="57.2" cy="45.5" r="1" fill={COLORS.white} />
          </>
        )}
        {eyeType === 'happy' && (
          <>
            <path d="M38,48 Q42,44 46,48" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
            <path d="M54,48 Q58,44 62,48" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
          </>
        )}
        {eyeType === 'sad' && (
          <>
            <path d="M38,46 Q42,50 46,46" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
            <path d="M54,46 Q58,50 62,46" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
            {/* Tear */}
            <path d="M42,51 C42,54 40,55 39,55 C38,55 37,54 37,52 C37,50 42,48 42,51 Z" fill={COLORS.blueLight} />
          </>
        )}
        {eyeType === 'pain' && (
          <>
            <path d="M39,45 L45,49 M45,45 L39,49" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
            <path d="M55,45 L61,49 M61,45 L55,49" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
          </>
        )}
        {eyeType === 'sleep' && (
          <>
            <path d="M38,48 Q42,51 46,48" fill="none" stroke={COLORS.outline} strokeWidth="3" strokeLinecap="round" />
            <path d="M54,48 Q58,51 62,48" fill="none" stroke={COLORS.outline} strokeWidth="3" strokeLinecap="round" />
          </>
        )}

        {/* Accessories */}
        {avatarConfig?.accessory === 'glasses' && (
          <>
            <circle cx="42" cy="47" r="6" fill="none" stroke={COLORS.outline} strokeWidth="2" />
            <circle cx="58" cy="47" r="6" fill="none" stroke={COLORS.outline} strokeWidth="2" />
            <path d="M48,47 L52,47" stroke={COLORS.outline} strokeWidth="2" />
            <path d="M36,47 L31,47 M64,47 L69,47" stroke={COLORS.outline} strokeWidth="2" />
          </>
        )}
        {avatarConfig?.accessory === 'hearing-aid' && (
          <path d="M69,44 Q74,44 74,48 Q74,52 69,52" fill={COLORS.grey} stroke={COLORS.outline} strokeWidth="2" />
        )}
        {avatarConfig?.accessory === 'headband' && (
          <path d="M31,40 Q50,32 69,40" fill="none" stroke={COLORS.pink} strokeWidth="4" strokeLinecap="round" />
        )}

        {/* Eyebrows */}
        {eyeType === 'sad' || eyeType === 'pain' ? (
          <>
            <path d="M37,41 Q42,43 45,39" fill="none" stroke={COLORS.outline} strokeWidth="2.5" strokeLinecap="round" />
            <path d="M63,41 Q58,43 55,39" fill="none" stroke={COLORS.outline} strokeWidth="2.5" strokeLinecap="round" />
          </>
        ) : (
          <>
            <path d="M37,41 Q42,39 45,41" fill="none" stroke={COLORS.outline} strokeWidth="2.5" strokeLinecap="round" />
            <path d="M63,41 Q58,39 55,41" fill="none" stroke={COLORS.outline} strokeWidth="2.5" strokeLinecap="round" />
          </>
        )}

        {/* Mouth */}
        {mouthType === 'smile' && (
          <path d="M44,55 Q50,60 56,55" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
        )}
         {mouthType === 'open' && (
          <path d="M44,53 Q50,61 56,53 C56,53 54,61 50,61 C46,61 44,53 44,53 Z" fill={COLORS.red} stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
        )}
        {mouthType === 'neutral' && (
          <path d="M45,56 L55,56" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
        )}
        {mouthType === 'sad' && (
          <path d="M44,58 Q50,53 56,58" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
        )}
        {mouthType === 'pain' && (
          <path d="M45,55 Q50,58 55,54" fill="none" stroke={COLORS.outline} strokeWidth="3.5" strokeLinecap="round" />
        )}
      </>
    );
  };

  // Switch to find key vector cards
  const getCustomVectorElement = () => {
    // 1. "QUERO" (I want) - Girl pointing to herself happily
    if (normLabel === 'quero' || normLabel === 'desejar' || normEmoji === '🙋‍♂️') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          {/* Background Card Base */}
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Girl Head */}
          {drawBaseGirl({ eyeType: 'normal', mouthType: 'smile' })}

          {/* Arm Pointing Back to Chest */}
          <path 
            d="M25,82 Q32,80 38,76 Q44,72 45,70" 
            fill="none" 
            stroke={COLORS.outline} 
            strokeWidth="4" 
            strokeLinecap="round" 
          />
          {/* Pointing hand details */}
          <path 
            d="M45,70 Q43,65 39,68 C35,71 39,78 43,76 Z" 
            fill={COLORS.skin} 
            stroke={COLORS.outline} 
            strokeWidth="3" 
            strokeLinejoin="round" 
          />
          
          {/* Label Card Inner Bottom border line with name label */}
          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>quero</text>
        </svg>
      );
    }

    // 2. "NÃO" (no) - Stop hand gesture
    if (normLabel === 'nao' || normLabel === 'recuso' || normEmoji === '🛑' || normEmoji === '👎') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head with neutral look */}
          {drawBaseGirl({ eyeType: 'normal', mouthType: 'neutral' })}

          {/* Stop Hand Gesture */}
          {/* Arm */}
          <path d="M26,85 Q21,78 22,66 L25,58" fill="none" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" />
          
          {/* Big Open Hand Raised Up */}
          <path 
            d="M20,58 C18,52 23,50 25,55 L25,38 C25,34 29,34 29,38 L29,54 C30,54 33,37 33,40 L33,52 C33,52 37,39 37,42 L37,55 L32,60 Z" 
            fill={COLORS.skin} 
            stroke={COLORS.outline} 
            strokeWidth="3" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
          />
          
          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>não</text>
        </svg>
      );
    }

    // 3. "AJUDA" (Help) - Hands joined in pleading
    if (normLabel === 'ajuda' || normLabel === 'ajudar' || normLabel === 'me ajuda' || normEmoji === '🤝') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head with pleading expression */}
          {drawBaseGirl({ eyeType: 'sad', mouthType: 'neutral' })}

          {/* Clasped Hands */}
          <path 
            d="M44,76 C42,65 47,65 50,68 C53,65 58,65 56,76 L52,82 L48,82 Z" 
            fill={COLORS.skin} 
            stroke={COLORS.outline} 
            strokeWidth="3.2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
          />
          {/* Wrists details */}
          <path d="M42,82 L41,92 M58,82 L59,92" stroke={COLORS.outline} strokeWidth="4" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>ajuda</text>
        </svg>
      );
    }

    // 4. "MAIS" (More) - Palms facing each other
    if (normLabel === 'mais' || normLabel === 'mais!' || normEmoji === '🤲') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Left Hand */}
          <path 
            d="M30,30 Q18,34 22,48 Q26,62 34,54" 
            fill={COLORS.skin} 
            stroke={COLORS.outline} 
            strokeWidth="3.5" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
          />
          {/* Hand lines */}
          <path d="M26,38 L16,42 M24,46 L14,48 M25,52 L16,52" stroke={COLORS.outline} strokeWidth="3.2" strokeLinecap="round" />

          {/* Right Hand */}
          <path 
            d="M70,30 Q82,34 78,48 Q74,62 66,54" 
            fill={COLORS.skin} 
            stroke={COLORS.outline} 
            strokeWidth="3.5" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
          />
          <path d="M74,38 L84,42 M76,46 L86,48 M75,52 L84,52" stroke={COLORS.outline} strokeWidth="3.2" strokeLinecap="round" />

          {/* Double Interaction arrow */}
          <path d="M38,44 L62,44" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" />
          <path d="M44,38 L38,44 L44,50" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M56,38 L62,44 L56,50" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>mais</text>
        </svg>
      );
    }

    // 5. "ACABOU" (Finished) - Shrug gesture + XBubble
    if (normLabel === 'acabou' || normLabel === 'fim' || normEmoji === '⏰') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt with shoulders wide */}
          <path d="M24,70 L76,70 L80,95 L20,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head with curious look */}
          {drawBaseGirl({ eyeType: 'sad', mouthType: 'neutral' })}

          {/* Shrugging Arms/Hands */}
          {/* Left shrug */}
          <path d="M22,74 Q15,64 12,65" stroke={COLORS.outline} strokeWidth="4" strokeLinecap="round" />
          <path d="M12,65 Q8,60 12,56 C16,52 18,58 18,63 L22,70 Z" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3" />
          
          {/* Right shrug */}
          <path d="M78,74 Q85,64 88,65" stroke={COLORS.outline} strokeWidth="4" strokeLinecap="round" />
          <path d="M88,65 Q92,60 88,56 C84,52 82,58 82,63 L78,70 Z" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3" />

          {/* Red X Bubble in corner */}
          <circle cx="82" cy="22" r="10" fill={COLORS.white} stroke={COLORS.red} strokeWidth="3" />
          <path d="M76,16 L88,28 M88,16 L76,28" stroke={COLORS.red} strokeWidth="3.5" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>acabou</text>
        </svg>
      );
    }

    // 6. "COMER" (Eat) - Spoon + Plate
    if (normLabel === 'comer' || normLabel === 'fome' || normEmoji === '🍽️' || normEmoji === '🍛') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Head & Hand eating */}
          {drawBaseGirl({ eyeType: 'happy', mouthType: 'open' })}

          {/* Spoons with bite food heading to mouth */}
          <path d="M24,78 Q22,58 40,54" fill="none" stroke={COLORS.outline} strokeWidth="4" strokeLinecap="round" />
          <rect x="36" y="50" width="10" height="6" rx="3" fill="#e0f2fe" stroke={COLORS.outline} strokeWidth="2.5" />
          {/* food on spoon */}
          <circle cx="39" cy="49" r="2.5" fill="#f59e0b" />

          {/* Rice bowl at bottom */}
          <path d="M12,78 L38,78 Q25,92 12,78 Z" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="3" />
          <path d="M14,75 C20,74 24,74 36,75" stroke={COLORS.outline} strokeWidth="2.5" />
          {/* rice beads inside */}
          <ellipse cx="20" cy="74.5" rx="1.5" ry="1" fill="#e2e8f0" />
          <ellipse cx="25" cy="73.5" rx="1.5" ry="1" fill="#cbd5e1" />
          <ellipse cx="28" cy="74.5" rx="1.5" ry="1" fill="#e2e8f0" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>comer</text>
        </svg>
      );
    }

    // 7. "BEBER" (Drink) - Glass + Water
    if (normLabel === 'beber' || normLabel === 'beber agua' || normEmoji === '🥤') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head */}
          {drawBaseGirl({ eyeType: 'happy', mouthType: 'open' })}

          {/* Glass filled with blue water near the mouth */}
          <path d="M25,65 L21,48 L35,46 L38,62 Z" fill={COLORS.blueLight} stroke={COLORS.outline} strokeWidth="3" strokeLinejoin="round" />
          {/* Wave line water inside */}
          <path d="M22.5,54 Q28,52 33.5,50" fill="none" stroke={COLORS.outline} strokeWidth="2.5" />

          {/* Arm holding cup */}
          <path d="M25,82 Q19,74 21,68" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>beber</text>
        </svg>
      );
    }

    // 8. "BANHEIRO" (Toilet) - Tolet bowl vectors
    if (normLabel === 'banheiro' || normLabel === 'sanitario' || normEmoji === '🚽') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Flush Tank behind */}
          <rect x="42" y="24" width="36" height="28" rx="4" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="3.5" />
          <rect x="48" y="29" width="6" height="4" rx="1" fill={COLORS.grey} stroke={COLORS.outline} strokeWidth="2" />
          
          {/* Base bowl structure */}
          <path d="M24,52 L48,52 Q50,75 42,88 L34,88 Q20,70 24,52 Z" fill="#f3f4f6" stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          {/* Floor Stand */}
          <ellipse cx="38" cy="88" rx="8" ry="2" fill={COLORS.grey} />

          {/* Toilet Seat rim */}
          <ellipse cx="34" cy="52" rx="14" ry="7" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="4.5" />
          {/* Blue inside water cavity */}
          <ellipse cx="34" cy="52" rx="8" ry="3.5" fill={COLORS.blueLight} />

          {/* Toilet cover lifted */}
          <path d="M48,51 L51,32 Q62,35 48,51 Z" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="3" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>banheiro</text>
        </svg>
      );
    }

    // 9. "DOR" (Pain) - Clutching chest, wincing
    if (normLabel === 'dor' || normLabel === 'machucado' || normEmoji === '🤕' || normEmoji === '🩹') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base head doing pain face */}
          {drawBaseGirl({ eyeType: 'pain', mouthType: 'pain' })}

          {/* Arm holding heart / chest area */}
          <path d="M68,85 Q60,78 51,76" fill="none" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" />
          <path d="M51,76 Q47,73 48,70 C49,67 54,71 52,75 Z" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3.2" />

          {/* Red Pain Sparks radiating from chest side */}
          <path d="M78,65 L84,61 M82,71 L90,73" stroke={COLORS.red} strokeWidth="3.5" strokeLinecap="round" />
          <path d="M76,77 L83,82" stroke={COLORS.red} strokeWidth="3.5" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>dor</text>
        </svg>
      );
    }

    // 10. "BRINCAR" (Play) - Colorful toy blocks
    if (normLabel === 'brincar' || normLabel === 'jogo' || normEmoji === '🧩' || normEmoji === '🥋') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head */}
          {drawBaseGirl({ eyeType: 'happy', mouthType: 'smile' })}

          {/* Toy elements in bottom-right/left */}
          {/* Block 1 (Blue Cube) */}
          <rect x="14" y="74" width="12" height="12" rx="1" fill={COLORS.blue} stroke={COLORS.outline} strokeWidth="2.5" />
          {/* Block 2 (Green Cube) */}
          <rect x="26" y="74" width="12" height="12" rx="1" fill={COLORS.green} stroke={COLORS.outline} strokeWidth="2.5" />
          {/* Block 3 (Red triangle rooftop) */}
          <path d="M20,62 L12,74 L28,74 Z" fill={COLORS.red} stroke={COLORS.outline} strokeWidth="2.5" strokeLinejoin="round" />
          {/* Block 4 (Yellow Cylinder next to them) */}
          <rect x="39" y="77" width="10" height="9" rx="1" fill={COLORS.yellow} stroke={COLORS.outline} strokeWidth="2.5" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>brincar</text>
        </svg>
      );
    }

    // 11. "DORMIR" (Sleep) - In bed with cover
    if (normLabel === 'dormir' || normLabel === 'sono' || normEmoji === '🛌' || normEmoji === '💤') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Pillow */}
          <rect x="12" y="36" width="22" height="30" rx="6" fill={accentLightColor} stroke={COLORS.outline} strokeWidth="3" />

          {/* Bed Sheet blanket back */}
          <rect x="30" y="44" width="58" height="42" rx="2" fill="#fdf2f8" stroke={COLORS.outline} strokeWidth="3.5" />

          {/* Sleeping Girl Head tilted horizontally */}
          <g transform="rotate(12, 33, 44)">
            {/* Hair back */}
            <path d="M12,38 C6,38 2,46 4,54 C6,62 14,62 18,56" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="3" />
            <circle cx="21" cy="48" r="16" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3.5" />
            <path d="M12,41 C12,31 41,31 41,41 Q33,33 21,33 Q12,33 12,41" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="3" />
            
            {/* Closed eye */}
            <path d="M18,48 Q22,51 26,48" fill="none" stroke={COLORS.outline} strokeWidth="3" strokeLinecap="round" />
            <ellipse cx="16" cy="51" rx="1.5" ry="1" fill={cheekColor} />
            
            {/* Smiling sleeping arc mouth */}
            <path d="M22,54 Q25,56 28,53" fill="none" stroke={COLORS.outline} strokeWidth="2.5" strokeLinecap="round" />
          </g>

          {/* Pink dotted cozy blanket code */}
          <path d="M32,54 L88,54 L88,84 L32,84 Z" fill={accentColor} stroke={COLORS.outline} strokeWidth="3.2" strokeLinejoin="round" />
          {/* Flower Dots on blanket */}
          <circle cx="42" cy="62" r="2" fill={COLORS.white} />
          <circle cx="56" cy="74" r="2" fill={COLORS.white} />
          <circle cx="70" cy="64" r="2" fill={COLORS.white} />
          <circle cx="82" cy="72" r="2" fill={COLORS.white} />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>dormir</text>
        </svg>
      );
    }

    // 12. "FELIZ" (Happy) - Arms up jump
    if (normLabel === 'feliz' || normLabel === 'alegre' || normEmoji === '😊' || normEmoji === '😀') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Arms up happily */}
          {/* Left Arm raised UP */}
          <path d="M26,62 Q16,48 10,48" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" />
          <circle cx="10" cy="48" r="4.5" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3" />

          {/* Right Arm raised UP */}
          <path d="M74,62 Q84,48 90,48" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" />
          <circle cx="90" cy="48" r="4.5" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3" />

          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />

          {/* Base Head */}
          {drawBaseGirl({ eyeType: 'happy', mouthType: 'open' })}

          {/* Yellow sparks of joy */}
          <path d="M14,35 L20,38" stroke={COLORS.yellow} strokeWidth="3" strokeLinecap="round" />
          <path d="M86,35 L80,38" stroke={COLORS.yellow} strokeWidth="3" strokeLinecap="round" />
          <path d="M50,22 L50,16" stroke={COLORS.yellow} strokeWidth="3.2" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>feliz</text>
        </svg>
      );
    }

    // 13. "TRISTE" (Sad)
    if (normLabel === 'triste' || normLabel === 'chateado' || normEmoji === '😢' || normEmoji === '🙁') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Sloping shoulders shirt */}
          <path d="M32,68 L68,68 L72,95 L28,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base head with sadness tears */}
          {drawBaseGirl({ eyeType: 'sad', mouthType: 'sad' })}

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>triste</text>
        </svg>
      );
    }

    // 14. "FOME" (Hungry) - Belly touch + Hamburger thought bubble
    if (normLabel === 'fome' || normEmoji === '🍔') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head looking eager */}
          {drawBaseGirl({ eyeType: 'sad', mouthType: 'smile' })}

          {/* Touch tummy arm */}
          <path d="M26,82 Q34,84 42,80" fill="none" stroke={COLORS.outline} strokeWidth="4" strokeLinecap="round" />
          <path d="M42,80 Q45,77 43,74 C41,71 36,75 39,78 Z" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3" />

          {/* Hamburger Thought bubble in corner */}
          <path d="M72,26 C72,21 86,21 86,26 C86,31 72,31 72,26 Z" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="1.5" />
          {/* Hamburger layers in miniature */}
          <path d="M74,25 Q79,22 84,25" fill={COLORS.yellow} stroke={COLORS.outline} strokeWidth="2" strokeLinecap="round" />
          <path d="M75,27 L83,27" fill={COLORS.red} stroke={COLORS.outline} strokeWidth="2.2" />

          {/* Bubbles leading to thought */}
          <circle cx="68" cy="33" r="2.5" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="1.5" />
          <circle cx="63" cy="38" r="1.5" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="1.2" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>fome</text>
        </svg>
      );
    }

    // 15. "SEDE" (Thirsty) - Holding cup
    if (normLabel === 'sede' || normLabel === 'beber agua' || normEmoji === '💧') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head */}
          {drawBaseGirl({ eyeType: 'normal', mouthType: 'smile' })}

          {/* Holding drinking glass filled with blue water */}
          <rect x="18" y="65" width="14" height="18" rx="2" fill={COLORS.blueLight} stroke={COLORS.outline} strokeWidth="3" />
          <path d="M18,74 L32,74" stroke={COLORS.outline} strokeWidth="2" />

          {/* Arm */}
          <path d="M24,84 Q30,81 33,83" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>sede</text>
        </svg>
      );
    }

    // 16. "QUENTE" (Hot) - Sweating girl + orange sun
    if (normLabel === 'quente' || normLabel === 'calor' || normEmoji === '🥵') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head with sweating look */}
          {drawBaseGirl({ eyeType: 'sad', mouthType: 'pain' })}

          {/* Sweat drop on face */}
          <circle cx="39" cy="51" r="1.5" fill={COLORS.blueLight} />
          <path d="M39,49.5 L39.5,51 M38.5,51 L39,52.5" stroke={COLORS.blue} strokeWidth="1" />

          {/* Hand wiping forehead with towel */}
          <path d="M68,54 L69,42 Q73,44 76,46 L74,56" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="2.5" strokeLinejoin="round" />
          <path d="M69,72 Q71,62 70,54" stroke={COLORS.outline} strokeWidth="4.5" strokeLinecap="round" />

          {/* Shining Mini Sun in top corner */}
          <circle cx="82" cy="22" r="7" fill={COLORS.yellow} stroke={COLORS.outline} strokeWidth="2.5" />
          {/* light rays */}
          <path d="M82,10 L82,13 M82,31 L82,34 M70,22 L73,22 M89,22 L92,22" stroke={COLORS.yellow} strokeWidth="2.5" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>quente</text>
        </svg>
      );
    }

    // 17. "FRIO" (Cold) - Shivering
    if (normLabel === 'frio' || normEmoji === '🥶') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shivering Body / Arms locked crossed clutching shoulders */}
          <path d="M30,68 L70,68 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head cold eyes */}
          {drawBaseGirl({ eyeType: 'pain', mouthType: 'sad' })}

          {/* Crossed Arms */}
          <path d="M26,76 Q50,86 54,74" fill="none" stroke={COLORS.outline} strokeWidth="4" strokeLinecap="round" />
          <path d="M74,76 Q50,86 46,74" fill="none" stroke={COLORS.outline} strokeWidth="4" strokeLinecap="round" />

          {/* Blue shivering waves on sides */}
          <path d="M16,42 Q14,48 16,54" fill="none" stroke={COLORS.blueLight} strokeWidth="2.5" strokeLinecap="round" />
          <path d="M84,42 Q86,48 84,54" fill="none" stroke={COLORS.blueLight} strokeWidth="2.5" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>frio</text>
        </svg>
      );
    }

    // 18. "MAMÃE" (Mommy) - Mommy theme with floating love heart
    if (normLabel === 'mamae' || normLabel === 'mae' || normEmoji === '👩') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={shirtColor} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Base Head */}
          {drawBaseGirl({ eyeType: 'happy', mouthType: 'smile' })}

          {/* Beautiful Floating Heart */}
          <path 
            d="M74,18 C70,14 62,18 66,24 C70,30 80,34 80,34 C80,34 90,30 94,24 C98,18 90,14 86,18 L80,24 Z" 
            fill={COLORS.red} 
            stroke={COLORS.outline} 
            strokeWidth="2.5" 
            strokeLinejoin="round" 
          />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>mamãe</text>
        </svg>
      );
    }

    // 19. "PAPAI" (Daddy) - Father with a cute cap
    if (normLabel === 'papai' || normLabel === 'pai' || normEmoji === '👨') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Green Shirt */}
          <path d="M30,66 L70,66 L75,95 L25,95 Z" fill={COLORS.green} stroke={COLORS.outline} strokeWidth="3.5" strokeLinejoin="round" />
          
          {/* Father Head Shell */}
          <circle cx="50" cy="48" r="19" fill={COLORS.skin} stroke={COLORS.outline} strokeWidth="3.5" />
          
          {/* Father beard outline */}
          <path d="M31,48 C31,64 69,64 69,48 Q50,68 31,48 Z" fill={COLORS.hair} stroke={COLORS.outline} strokeWidth="3" />

          {/* Father green baseball cap */}
          <path d="M29,38 C29,26 71,26 71,38 Z" fill={COLORS.green} stroke={COLORS.outline} strokeWidth="3.5" />
          {/* cap visor */}
          <path d="M24,38 Q50,28 76,38" fill={COLORS.green} stroke={COLORS.outline} strokeWidth="3" />

          {/* Face details */}
          <ellipse cx="42" cy="46" rx="2.5" ry="3" fill={COLORS.outline} />
          <ellipse cx="58" cy="46" rx="2.5" ry="3" fill={COLORS.outline} />
          <path d="M45,54 Q50,58 55,54" fill="none" stroke={COLORS.outline} strokeWidth="3.2" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>papai</text>
        </svg>
      );
    }

    // 20. "CASA" (Home)
    if (normLabel === 'casa' || normEmoji === '🏡' || normEmoji === '🏠') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* House body */}
          <rect x="22" y="44" width="56" height="42" rx="4" fill="#fef08a" stroke={COLORS.outline} strokeWidth="3.5" />
          
          {/* Rooftop */}
          <path d="M16,46 L50,16 L84,46 Z" fill={COLORS.red} stroke={COLORS.outline} strokeWidth="4" strokeLinejoin="round" />

          {/* Door */}
          <rect x="42" y="62" width="16" height="24" rx="2" fill="#b45309" stroke={COLORS.outline} strokeWidth="3" />
          <circle cx="46" cy="74" r="1.5" fill={COLORS.yellow} />

          {/* Window */}
          <rect x="28" y="52" width="12" height="12" rx="1" fill={COLORS.blueLight} stroke={COLORS.outline} strokeWidth="2.5" />
          <path d="M34,52 L34,64 M28,58 L40,58" stroke={COLORS.outline} strokeWidth="1.5" />

          {/* Chimney smoke */}
          <path d="M72,28 C74,23 71,20 73,15" fill="none" stroke={COLORS.grey} strokeWidth="3" strokeLinecap="round" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>casa</text>
        </svg>
      );
    }

    // 21. "ESCOLA" (School)
    if (normLabel === 'escola' || normEmoji === '🏫') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Main building structure */}
          <rect x="18" y="40" width="64" height="46" rx="4" fill="#e0f2fe" stroke={COLORS.outline} strokeWidth="3.5" />
          {/* middle tower */}
          <rect x="38" y="24" width="24" height="20" rx="2" fill="#bae6fd" stroke={COLORS.outline} strokeWidth="3" />
          
          {/* Clock face on school tower */}
          <circle cx="50" cy="34" r="6" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="2" />
          {/* hands */}
          <path d="M50,34 L50,31 M50,34 L53,34" stroke={COLORS.outline} strokeWidth="1.5" strokeLinecap="round" />

          {/* School sign Red roof trim */}
          <path d="M34,24 L50,14 L66,24 Z" fill={COLORS.red} stroke={COLORS.outline} strokeWidth="3" strokeLinejoin="round" />

          {/* School Entrance Pillar Doors */}
          <rect x="42" y="60" width="16" height="26" rgb="2" fill="#d1fae5" stroke={COLORS.outline} strokeWidth="2.5" />
          <path d="M50,60 L50,86" stroke={COLORS.outline} strokeWidth="2" />

          {/* Windows */}
          <rect x="24" y="48" width="10" height="10" rx="1.5" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="2.5" />
          <rect x="66" y="48" width="10" height="10" rx="1.5" fill={COLORS.white} stroke={COLORS.outline} strokeWidth="2.5" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>escola</text>
        </svg>
      );
    }

    // 22. "SABOR RECOMPENSA" / "CHOCOLATE"
    if (normLabel === 'chocolate' || normEmoji === '🍫') {
      return (
        <svg viewBox="0 0 100 100" className={className}>
          <rect x="3" y="3" width="94" height="94" rx="14" fill="#ffffff" stroke={COLORS.outline} strokeWidth="4" />
          
          {/* Chocolate bar wrapped */}
          <rect x="25" y="25" width="50" height="50" rx="2" fill="#78350f" stroke={COLORS.outline} strokeWidth="3.5" />
          
          {/* Chocolate blocks grid indent cuts */}
          <path d="M25,41 L75,41 M25,58 L75,58 M42,25 L42,75 M58,25 L58,75" stroke="#451a03" strokeWidth="2.5" />

          {/* Tear packaging look */}
          <path d="M22,46 L78,46 L74,77 L26,77 Z" fill={COLORS.red} stroke={COLORS.outline} strokeWidth="3" strokeLinejoin="round" />
          <path d="M22,46 Q50,56 78,46" fill="none" stroke={COLORS.yellow} strokeWidth="2" />

          <text x="50" y="91" textAnchor="middle" className="font-sans font-black text-[12px]" fill={COLORS.outline}>chocolate</text>
        </svg>
      );
    }

    // Return null to fall back gracefully to elegant emoji styling
    return null;
  };

  const customVector = getCustomVectorElement();
  if (customVector) {
    return customVector;
  }

  // Graceful, polished fallback: Standard emojis placed inside a beautifully outlined pediatric PECS card!
  // This maintains the exact consistent presentation of a real PECS card: White card background, thick border,
  // stylized colored header base matching category, emoji placed lovingly in center, text label at bottom.
  // It completely removes the "poor, plain text emoji" feel even for customized user-created button cards!
  
  // Choose fallback categories mapping colors
  const catColors: Record<string, { bg: string, labelBg: string }> = {
    actions: { bg: "bg-amber-50", labelBg: "bg-amber-100" },
    feelings: { bg: "bg-indigo-50", labelBg: "bg-indigo-100" },
    basic_needs: { bg: "bg-red-50", labelBg: "bg-red-100" },
    people: { bg: "bg-sky-50", labelBg: "bg-sky-100" },
    food: { bg: "bg-emerald-50", labelBg: "bg-emerald-100" },
    objects: { bg: "bg-pink-50", labelBg: "bg-pink-100" },
    places: { bg: "bg-teal-50", labelBg: "bg-teal-100" },
    school: { bg: "bg-purple-50", labelBg: "bg-purple-100" },
  };

  const colorsUsed = catColors[category] || { bg: "bg-slate-50/50", labelBg: "bg-slate-100" };

  return (
    <div className={`w-full h-full relative border-[3.5px] border-slate-900 rounded-2xl bg-white flex flex-col justify-between p-1.5 transition-all select-none overflow-hidden aspect-square ${className}`}>
      {/* Dynamic top bar color based on category */}
      <div className={`w-full h-1/6 rounded-lg ${category ? colorsUsed.labelBg : 'bg-slate-100/60'} border-b-2 border-slate-900 flex items-center justify-center text-slate-800`}>
        <span className="text-[9px] uppercase font-black leading-none tracking-widest truncate px-1 max-w-full">
          {category || 'PECS Alternative'}
        </span>
      </div>

      {/* Emoji centerpiece rendered nicely with shadows */}
      <div className="flex-1 flex items-center justify-center relative">
        <span className="text-5xl drop-shadow-[0_4px_6px_rgba(0,0,0,0.15)] filter saturate-120 animate-fade-in my-auto scale-102 hover:scale-108 transition-transform">
          {normEmoji || '💬'}
        </span>
      </div>

      {/* Label beautifully centered below like in standard cards */}
      <div className="w-full h-1/5 rounded-lg border-t border-slate-200 bg-slate-50 flex items-center justify-center font-bold text-slate-900 text-[10.5px] max-h-[30px] leading-none shrink-0 truncate px-1 font-mono uppercase">
        {label || 'Cartão'}
      </div>
    </div>
  );
};
